<template lang="">
   <div>
    12334445
   </div>
</template>
<script setup>
definePageMeta({
  layout: 'profile'
})
</script>
<style lang="">
    
</style>