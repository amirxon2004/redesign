<template lang="">
   <div class="" >
  <div class="f-container h-full flex gap-4">
    <div class="w-[240px] h-full border-r">
      <div class="scroll h-full px-1 py-2 default">
        <ul>
          <!--[-->
          <li><a href="/product" class="py-2 px-3 rounded-xl flex items-center text-sm font-medium gap-3 text-gray-700 justify-between hover:!text-green-500 hover:bg-green-100">
              <div class="flex items-center gap-3"> Kategoriya 1</div>
            </a></li>
          <li><a href="/product" class="py-2 px-3 rounded-xl flex items-center text-sm font-medium gap-3 text-gray-700 justify-between hover:!text-green-500 hover:bg-green-100">
              <div class="flex items-center gap-3"> Kategoriya 2</div>
            </a></li>
        </ul>
      </div>
    </div>
    <div class="flex-1 py-3 px-2 h-full scroll default">
      <div class="flex items-center gap-2 mb-4">
        <h1 class="text-lg font-bold text-gray-700">Kategoriya 1 </h1>
      </div>
      <div class="grid grid-cols-4 gap-4">
        <!--[-->
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 1</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 2</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 3</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 4</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 5</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 6</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 7</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 8</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 9</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex items-center mb-2">
            <h1 class="text-sm font-bold text-gray-600">Kategoriya 10</h1>
          </div>
          <div class="w-full">
            <ul>
              <!--[-->
              <li><a href="/product" class="mb-1 py-1 rounded-xl flex items-center text-sm gap-3 text-gray-400 font-medium justify-between hover:!text-green-500">
                  <div class="flex items-center gap-3"> Kategoriya 1</div>
                </a></li>
              <!--]-->
            </ul>
          </div>
        </div>
        <!--]-->
      </div>
    </div>
  </div>
</div>
</template>
<script setup>

const props = defineProps(['class']);

</script>
<style lang="">
    
</style>