<template lang="">
    <div>
        13
    </div>
</template>
<script setup>
definePageMeta({
  layout: 'profile'
})
</script>
<style lang="">
    
</style>