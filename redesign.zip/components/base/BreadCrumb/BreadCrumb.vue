<template lang="">
   <div class="text-base font-medium my-5 gap-2 flex">
    <span>Главная</span>
    <span>/</span>
    <span class="text-slate-500">Страница</span>
   </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>