<template>
    <div>
      <MyHeader />
      <div class="container">
        <NuxtPage />
      </div>
      <MyFooter />
    </div>

    
  </template> 
<script>

</script>

<style>
@media not all and (min-width: 1430px) {

.container {
    padding-left: 1rem;
    padding-right: 1rem;
}
}
.container {
    max-width: 1440px !important;
}
</style>