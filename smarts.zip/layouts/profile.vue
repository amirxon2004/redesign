<template>
    <MyHeader />
    <BaseBreadCrumb />
    <div class="my-10 grid grid-cols-4 gap-5">
       <BaseMenuProfile />
        <div class="grid-cols-3">     
    <!-- <BaseProfilePage>
    </BaseProfilePage> -->
    <NuxtPage />
    
        </div>
    </div> 
    <MyFooter />

</template> 
<script setup> 
 

</script>
<style>
 
</style> 