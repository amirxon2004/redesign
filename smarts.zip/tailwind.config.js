/** @type {import('tailwindcss').Config} */
module.exports = {
    theme: {
      container: {
        center: true,
       
      },
    },
    // Other Tailwind CSS configuration goes here
  } 