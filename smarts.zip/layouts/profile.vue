<template>
    <MyHeader />
    <div class="container">
        <BaseBreadCrumb />
    <div class="my-10 grid grid-cols-4 gap-5">
       <div class="col-span-1">
        <BaseMenuProfile />
       </div>
        <div class="col-span-3">    
        <NuxtPage />
        </div>
    </div> 
    </div>
    <MyFooter />

</template> 
<script setup> 
 

</script>
<style>
 
</style> 