<template>
   <BaseBreadCrumb />
    <div class="my-10 grid grid-cols-4 gap-5">
       <BaseMenuProfile />
        <div class="grid-cols-3">     
    <!-- <BaseProfilePage>
        <NuxtPage />
    </BaseProfilePage> -->
    123
        </div>
    </div> 
</template>
<script setup>
const layout = "ProfileLayout";

</script>
<style>
 
</style>