<template lang="">
    <div>
        132
    </div>
</template>
<script setup>
definePageMeta({
  layout: 'profile'
})
</script>
<style lang="">
    
</style>