
<template>
  
        
   
  </template>
  
  <script setup>
  import { defineProps } from 'vue';
  import { Nuxt } from 'nuxt';
  
  const props = defineProps(['layout']);
  
 
  </script>
  
  <style scoped>
  /* Your styles if needed */
  </style>