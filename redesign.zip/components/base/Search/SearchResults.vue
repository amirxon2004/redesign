<template lang="">

  <div class="w-full pt-5">
    <ul>
      <li><a href="/" class="router-link-active router-link-exact-active flex items-center gap-2 mb-1 rounded-lg" aria-current="page">
          <div class="w-8 h-8 flex justify-center items-center p-1"></div>
          <div class="border-b flex-1 p-1">
            <p class="text-sm font-medium text-gray-700">Olma</p>
          </div>
        </a></li>
        <li><a href="/" class="router-link-active router-link-exact-active flex items-center gap-2 mb-1 rounded-lg" aria-current="page">
          <div class="w-8 h-8 flex justify-center items-center p-1"></div>
          <div class="border-b flex-1 p-1">
            <p class="text-sm font-medium text-gray-700">Olma</p>
          </div>
        </a></li>
        <li><a href="/" class="router-link-active router-link-exact-active flex items-center gap-2 mb-1 rounded-lg" aria-current="page">
          <div class="w-8 h-8 flex justify-center items-center p-1"></div>
          <div class="border-b flex-1 p-1">
            <p class="text-sm font-medium text-gray-700">Olma</p>
          </div>
        </a></li>
    </ul>
  </div>
</template>
<script>

</script>
<style lang="">
    
</style>