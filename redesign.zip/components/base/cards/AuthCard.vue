<template lang="">
  
    <div class="relative bg-white z-10 rounded-xl w-full max-w-[400px]">
        <div class="w-full p-5 pb-0 flex justify-between items-start gap-2">
            <!---->
            <button type="button" class="end-2.5 text-gray-400 bg-gray-100 hover:bg-green-200 hover:text-green-800 rounded-full text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"></path>
                </svg>
            </button>
        </div>
        <div class="w-full">
            <!--[-->
            <div class="w-full p-6 pt-2">
                <h1 class="font-bold text-2xl text-gray-700 mb-2">Telefon raqamingizni kiriting</h1>
                <p class="text-sm text-gray-500 mb-4">Telefon raqamingizni kiriting ro'yxatdan o'ting yoki tizimga kiring.</p>
                <div class="w-full mb-4">
                    <p class="text-sm mb-2 font-bold text-gray-600">Telefon raqam <span class="text-red-500">*</span></p>
                    <div class="w-full relative">
                        <div class="absolute h-full px-2 py-1 w-24 flex justify-center items-center">
                            <button class="font-medium text-xs flex gap-1 items-center text-gray-600 p-2 bg-gray-100 rounded-xl w-full justify-center">
                                <img
                                    class="w-3"
                                    src=""
                                    alt=""
                                />
                                <span class="text-[12px] flex-1 overflow-hidden">+998</span>
                            </button>
                        </div>
                        <input class="w-full h-12 pl-24 border rounded-xl px-4 py-3 outline-none text-base focus:border-green-500" type="text" placeholder="-- --- -- --" />
                    </div>
                </div>
                <div class="w-full mb-4">
                    <button class="font-bold text-white h-12 border rounded-xl px-5 py-3 outline-none text-base bg-primary w-full"><!--[-->Kirish<!--]--></button>
                </div>
                <div class="w-full mt-8 relative flex justify-center">
                    <p class="bg-white p-4 text-sm relative z-[1] font-bold text-gray-500">Yoki</p>
                    <div class="absolute top-0 left-0 w-full h-full flex items-center z-0"><div class="w-full border-b"></div></div>
                </div>
                <div class="w-full grid grid-cols-2 gap-2">
                    <div class="col-span-1 p-4 rounded-xl border cursor-pointer flex justify-center items-center hover:bg-green-100 hover:border-green-500">
                        <img
                            class="h-5"
                            src=""
                            alt=""
                        />
                    </div>
                    <div class="col-span-1 p-4 rounded-xl border cursor-pointer flex justify-center items-center hover:bg-green-100 hover:border-green-500">
                        <img
                            class="h-5"
                            src=""
                            alt=""
                        />
                    </div>
                    <div class="col-span-1 p-4 rounded-xl border cursor-pointer text-center font-bold text-sm text-gray-600 flex items-center justify-center hover:bg-green-100 hover:border-green-500">
                        <img class="mr-3 h-5" src="" alt="" /> Ariza raqami
                    </div>
                    <div class="col-span-1 p-4 rounded-xl border cursor-pointer text-center font-bold text-sm text-gray-600 flex items-center justify-center hover:bg-green-100 hover:border-green-500">
                        <img class="mr-3 h-5" src="" alt="" /> Face-ID
                    </div>
                    <!---->
                </div>
                <div class="w-full mt-6">
                    <p class="text-center text-sm text-gray-500">Avtotizatsiyadan o'tish orqali siz <span class="text-primary">shaxsiy ma'lumotlarni qayta ishlash siyosatiga</span> rozilik bildirasiz</p>
                </div>
            </div>
            <!--]-->
        </div>
    </div>



</template>
<script>

</script>
<style lang="">
    
</style>